package com.car.mfg.app;

/*
 * Web Application main
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan({
	"com.car.mfg.controller",
	"com.car.mfg.service",
	"com.car.mfg.exception"
})

@SpringBootApplication
public class CarMfgApplication {

    public static void main(String[] args) {
        SpringApplication.run(CarMfgApplication.class, args);
    }
}
