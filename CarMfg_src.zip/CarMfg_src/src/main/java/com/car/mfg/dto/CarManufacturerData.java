package com.car.mfg.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class CarManufacturerData implements Serializable {

	private static final long serialVersionUID = 1L;

	public CarManufacturerData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CarManufacturerData(List<Manufacturer> data) {
		super();
		this.data = data;
	}

	public List<Manufacturer> getData() {
		return data;
	}

	public void setData(List<Manufacturer> data) {
		this.data = data;
	}

	private List<Manufacturer> data;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof CarManufacturerData)) {
			return false;
		}
		CarManufacturerData other = (CarManufacturerData) obj;
		if (data == null) {
			if (other.data != null) {
				return false;
			}
		} else if (!data.equals(other.data)) {
			return false;
		}
		return true;
	}
}
