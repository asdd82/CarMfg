package com.car.mfg.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class VehicleType implements Serializable {

	private static final long serialVersionUID = 1L;

	public VehicleType() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VehicleType(Boolean isPrimary, String name) {
		super();
		this.isPrimary = isPrimary;
		this.name = name;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((isPrimary == null) ? 0 : isPrimary.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof VehicleType)) {
			return false;
		}
		VehicleType other = (VehicleType) obj;
		if (isPrimary == null) {
			if (other.isPrimary != null) {
				return false;
			}
		} else if (!isPrimary.equals(other.isPrimary)) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}



	private Boolean isPrimary;
	private String name;

	public Boolean getIsPrimary() {
		return isPrimary;
	}

	public void setIsPrimary(Boolean isPrimary) {
		this.isPrimary = isPrimary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isMatch(String vehicleTypeName) {
		if (vehicleTypeName != null && ! vehicleTypeName.isEmpty()) {
			return vehicleTypeName.equalsIgnoreCase(this.getName());
		}
		
		return false;
	}
}
