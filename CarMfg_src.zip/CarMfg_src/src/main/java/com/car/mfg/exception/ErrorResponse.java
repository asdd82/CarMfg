package com.car.mfg.exception;

/*
 * error response object
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ErrorResponse {
	private static Logger log = LoggerFactory.getLogger(ErrorResponse.class);
	private int status;
	private String errorCode;
	private String errorMsg;
	private String errorDetail;
	private String timestamp;
	
	private void setErrorInfo(HttpStatus status, String errorCode, String errorMsg, String errorDetail){
		this.status = status.value();
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.errorDetail = errorDetail;
		setTimestamp();
	}
	public ErrorResponse() {
	}
	public ErrorResponse(HttpStatus status, String errorMsg){
		setErrorInfo(status, status.toString(), errorMsg, "" );
	}	
	
	public ErrorResponse(HttpStatus status, String errorCode, String errorMsg){
		setErrorInfo(status, errorCode, errorMsg, "");
	}
	
	public ErrorResponse(HttpStatus status, String errorCode, String errorMsg, String errorDetail){
		setErrorInfo(status, errorCode, errorMsg, errorDetail);
	}

	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}
	
	/**
	 * @param set the status
	 */
	public void setStatus(int status) {
		this.status = status;
	}
	
	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param set the errorCode
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}	

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getErrorDetail() {
		return errorDetail;
	}

	public void setErrorDetail(String errorDetail) {
		this.errorDetail = errorDetail;
	}	

	public void setTimestamp(){
		TimeZone timeZone = TimeZone.getTimeZone("UTC");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mmZ");
		dateFormat.setTimeZone(timeZone);
		timestamp = dateFormat.format(new Date());	//return the current time in  ISO 8601 format
	}
	
	public String getTimestamp(){
		return timestamp;
	}
	
	public static ErrorResponse parseError(String resposeBody){
		if(resposeBody!=null){
			try{
				ErrorResponse errorRes = new ObjectMapper().readValue(resposeBody, ErrorResponse.class);
				return errorRes;
			}catch(Exception e){
				log.debug("unable to parse response body as ErrorResponse, may be response body is some other object type {}",resposeBody,  e);
			}
		}
		return null;
	}
	
}
