package com.car.mfg.exception;

/*
 * class handles BadRequest
 */
public class BadRequestException extends ExceptionBase {
	private static final long serialVersionUID = 9130962438964624899L;

	public BadRequestException() {}

	public BadRequestException(String message)
	{
		super(message);
	}
	
	public BadRequestException(String errorCode, String message)
	{
		super(errorCode, message);
	}
	
	public BadRequestException(String errorCode, String message, String detail)
	{
		super(errorCode, message, detail);
	}	
}
