package com.car.mfg.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.util.StringUtils;

public class Tokenizer {
	private Tokenizer() {
	}
	public static List<String> extractSearchTerms(String queryString) {

        // Trim the string
        queryString = StringUtils.trimWhitespace(queryString);

        // Instantiate the list that will hold the tokens
        List<String> list = new ArrayList<>();

        if (queryString == null || queryString.isEmpty()) {
        	return list;
        }
        // Compile the tokenizer pattern; the pattern itself is rather a heuristic and is consisted
        // of 4 parts separated with an OR (pipe).
        //
        // The first part locates explicit property search (propertyName:value), e.g. Country:"USA" 
        //The second locates any phrase that may contain escaped double quotes. 
        //The third part locates strings concatenated with phrases. 
        //The last part locates any other string that contains no white spaces.
        //
        // ";" now included as a term separator.
        String pattern =
                "([\\w]+:=?\".+?(?<!\\\\)\")" + "|" + "([\\w]+(?=\\\")[\\w]+)" + "|"
                        + "([^\\s;]*\"[^:\\\\]+(?=\\\")*[^:\\\\]+\")" + "|" + "([^\\s;]+)";

        Pattern regex = Pattern.compile(pattern);

        // Create the matcher using the regex
        Matcher regexMatcher = regex.matcher(queryString);

        // Tokenize the string
        while (regexMatcher.find()) {

            // Use the whole matched string
            String match = regexMatcher.group(0);

            // The match can't be null here, but lets be sure
            if (match != null) {

                // Replace unescaped double quotes
                match = match.replaceAll("(?<!\\\\)\"", "");

                // Remove escapes (just the double quotes for now)
                match = match.replaceAll("\\\\\"", "\"");
                
                // Replace wildcards with SQL wildcards (*->% and ?->_)
                match = match.replaceAll("(?<!\\\\)\\*", "%");
                match = match.replaceAll("(?<!\\\\)\\?", "_");

                // Add the match if it's still not empty
                if (StringUtils.hasText(match)) {

                    list.add(match);
                }
            }
        }

        return list;
    }
}
