package com.car.mfg.controller;

/**
 * Controller for the CarMfgApplication REST web Server
 */

import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.car.mfg.dto.CarManufacturerData;
import com.car.mfg.dto.Manufacturer;
import com.car.mfg.service.CarMfgService;

@RestController
@RequestMapping(value = "/api")
public class CarMfgController {

	@Autowired
	CarMfgService carMfgService;

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * Get manufacturers
     * 
     * @throws Exception
     */
   @RequestMapping(
        value = "/car/mfg/v1/manufacturers",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CarManufacturerData> getManufactorers(      
        @RequestParam(value = "sort", required = false) Boolean sort,  
        @RequestParam(value = "orderByDesc", required = false) Boolean orderByDesc,  
        @RequestParam(value = "q", required = false) String queryIn
        ) throws Exception {
    
        log.debug("RequestID: {}, Module: CarMfgController, GET /api/car/mfg/v1/manufacturers", Thread.currentThread().getId());
        
        CarManufacturerData ret = carMfgService.getManufactorers(sort, orderByDesc, queryIn);
        
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }
   
   /**
    * Get a manufacturer
    * 
    * @throws Exception
    */
  @RequestMapping(
       value = "/car/mfg/v1/manufacturers/{id}",
       method = RequestMethod.GET,
       produces = MediaType.APPLICATION_JSON_VALUE)
   public ResponseEntity<Manufacturer> getManufactorer(   
		   @PathVariable(value = "id", required = true) Integer mfr_id
       ) throws Exception {
   
       log.debug("RequestID: {}, Module: CarMfgController, GET /api/car/mfg/v1/manufacturers/{id}", Thread.currentThread().getId());
       
       Manufacturer ret = carMfgService.getManufactorer(mfr_id);
       
       return new ResponseEntity<>(ret, HttpStatus.OK);
   	}
  
  /**
   * Delete a manufacturer
   * 
   * @throws Exception
   */
 @RequestMapping(
      value = "/car/mfg/v1/manufacturers/{id}",
      method = RequestMethod.DELETE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Boolean> deleteManufactorer(   
		   @PathVariable(value = "id", required = true) Integer mfr_id) throws Exception {
  
      log.debug("RequestID: {}, Module: CarMfgController, DELETE /api/car/mfg/v1/manufactorers/{id}", Thread.currentThread().getId());
      
      Boolean ret = carMfgService.deleteManufactorer(mfr_id);
      
      return new ResponseEntity<>(ret, HttpStatus.OK);
  	}
 
 /**
  * Delete all manufacturers
  * 
  * @throws Exception
  */
@RequestMapping(
     value = "/car/mfg/v1/manufacturers",
     method = RequestMethod.DELETE,
     produces = MediaType.APPLICATION_JSON_VALUE)
 public ResponseEntity<Integer> deleteManufactorers(   
     ) throws Exception {
 
     log.debug("RequestID: {}, Module: CarMfgController}, DELETE /api/car/mfg/v1/manufactorers", Thread.currentThread().getId());
     
     Integer ret = carMfgService.deleteManufactorers();
     
     return new ResponseEntity<>(ret, HttpStatus.OK);
 	}

/**
 * insert manufacturers
 * 
 * @throws Exception
 */
@RequestMapping(
    value = "/car/mfg/v1/manufacturers",
    method = RequestMethod.POST,
    produces = MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<CarManufacturerData> insertManufactorers(   
		   @RequestBody(required = true) Set<Manufacturer> manufacturers ) throws Exception {

    log.debug("RequestID: {}, Module: CarMfgController, POST /api/car/mfg/v1/manufacturers", 
    		Thread.currentThread().getId());
    
    CarManufacturerData ret = carMfgService.insertManufactorers(manufacturers);
    
    return new ResponseEntity<>(ret, HttpStatus.OK);
	}

/**
 * change a manufacturer
 * 
 * @throws Exception
 */
@RequestMapping(
    value = "/car/mfg/v1/manufacturer",
    method = RequestMethod.PATCH,
    produces = MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<Manufacturer> changeManufactorer(   
		   @RequestBody(required = true) Manufacturer manufacturer) throws Exception {

    log.debug("RequestID: {}, Module: CarMfgController, PATCH /api/car/mfg/v1/manufacturer", 
    		Thread.currentThread().getId());
    
    Manufacturer ret = carMfgService.changeManufactorer(manufacturer);
    
    return new ResponseEntity<>(ret, HttpStatus.OK);
	}

}
