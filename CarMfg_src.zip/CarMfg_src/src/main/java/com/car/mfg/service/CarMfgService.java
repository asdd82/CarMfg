package com.car.mfg.service;

import static java.nio.file.Files.readAllBytes;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import com.car.mfg.dto.CarManufacturerData;
import com.car.mfg.dto.Manufacturer;
import com.car.mfg.util.Tokenizer;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CarMfgService {

	private final Logger log = LoggerFactory.getLogger(this.getClass());
	private final static String initialDatFile = "carmfg_data.json";
	private final static String newDatFile = "carmfg_new_data.json";
	
    @Value("${car.mfg.data.folder:}")
    private String dataFolder;
    
	private ObjectMapper mapper = new ObjectMapper();
	 
	private  CarManufacturerData initialData ;
	
    public CarMfgService() {
       
    }
   
   
    //save the manufacturer data into a file on the system
    private void saveToFile() throws JsonGenerationException, JsonMappingException, IOException, URISyntaxException {
    	log.info("saveToFile: writing to file: {}", dataFolder+"\\"+newDatFile);
        
    	mapper.writerWithDefaultPrettyPrinter().writeValue(new File(dataFolder+"\\"+newDatFile), initialData);
    }
    
    //read from the provided static car manufacturer data file.
    @EventListener
    public void loadCarManufacturerData(ContextRefreshedEvent event) 
    		throws JsonParseException, JsonMappingException, IOException{
        
    	if (dataFolder == null || dataFolder.isEmpty() ) {
    		dataFolder = System.getProperty("user.dir");
    	}
    		
    	mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

    	Path p = Paths.get(dataFolder+"\\"+initialDatFile); //.getAbsolutePath());
    	byte[] bytes = readAllBytes(p);
    	 
	   	initialData =  mapper.readValue(bytes, new TypeReference<CarManufacturerData>() {});  
	   	 
	   	if (initialData == null) {
	   		//we want an empty dat, rather than a null
	   		initialData = new CarManufacturerData();
	   	}
    	    	 
    	if (initialData.getData()  == null) {
    	   	//empty manufacturer list
    	   	initialData.setData(new ArrayList<Manufacturer> ());		 
    	} else {
    		//remove any duplicates
    		initialData.setData(initialData.getData().stream().distinct().collect(Collectors.toList()));
    	}
    	
    	log.info("loadCarManufacturerData:loaded file: {}", p.toAbsolutePath());
    }
    
    //get all the manufacturer data, search, sort and order if required
	public CarManufacturerData getManufactorers(Boolean sort, Boolean orderByDesc, String queryIn) {
		
		log.info("getManufactorers sort: {}, order : {} ", sort, orderByDesc);
		
		//sorting: if specified, assuming sorting Country, then Name. Default NO sorting
		//ordering: sortByAsc, sortByDesc. Default sortByAsc
		//searching: if specified, assuming search Country, Name, Type. Default NO Search, display ALL.
		
		List<Manufacturer> listManufacturers = initialData.getData();
				
		//searching first: 
		//search pattern: queryIn=Country:"USA";Mfr_Name:"TESLA, INC.";VehicleTypeName:"Passenger Car"
		String country = null;
		String name = null;
		String vehicleTypeName = null;
		
		for (String item : Tokenizer.extractSearchTerms(queryIn)) {
    		if (item.toLowerCase().startsWith("country:")) {
    			/* Strip out value from name=value */
    			if (item.indexOf(':') != -1) {
    				country = item.substring(item.indexOf(':') + 1);
    			}
    		} else if (item.toLowerCase().startsWith("mfr_name:")) {
    			if (item.indexOf(':') != -1) {
    				name = item.substring(item.indexOf(':') + 1);
    			}
    		} else if (item.toLowerCase().startsWith("vehicletypename:")) {
    			if (item.indexOf(':') != -1) {
    				vehicleTypeName = item.substring(item.indexOf(':') + 1);
    			}
    		}
    	}
		
		//avoid 'Local variable country defined in an enclosing scope must be final or effectively final'?
		String country1 = country ;
		String name1 = name;
		String vehicleTypeName1 = vehicleTypeName;
		
		List<Manufacturer> filteredManufacturers = 
				listManufacturers.stream()
				.filter(m -> m.isMatch(country1, name1, vehicleTypeName1))
				.collect(Collectors.toList());
		
		if (sort != null && sort) {
			if (orderByDesc != null && orderByDesc) {
				filteredManufacturers.sort((m1,m2) -> {			
					int cmpCountry = m2.getCountry().compareToIgnoreCase(m1.getCountry());
					if (cmpCountry != 0) {
						return cmpCountry;
					}
					
					return m2.getMfr_Name().compareToIgnoreCase(m1.getMfr_Name());
				});
			} else {
				filteredManufacturers.sort((m1,m2) -> {			
					int cmpCountry = m1.getCountry().compareToIgnoreCase(m2.getCountry());
					if (cmpCountry != 0) {
						return cmpCountry;
					}
					
					return m1.getMfr_Name().compareToIgnoreCase(m2.getMfr_Name());
				});
			}
		}
			
		CarManufacturerData data = new CarManufacturerData();
		data.setData(filteredManufacturers);
		
		return data;
	}


	//get a manufacturer based on id
	public Manufacturer getManufactorer(Integer mfr_id) {
		
		log.info("getManufactorer: {}", mfr_id);
		for (Iterator<Manufacturer> iterator = initialData.getData().iterator(); iterator.hasNext();) {
			Manufacturer mf = iterator.next();
			
			if (mf.getMfr_ID().equals(mfr_id )) {
				return mf;
			}
		}
		
		//return an empty one
		return new Manufacturer();
	}


	//delete a manufacturer based on id
	public Boolean deleteManufactorer(Integer mfr_id) 
			throws JsonGenerationException, JsonMappingException, IOException, URISyntaxException {
		log.info("deleteManufactorer: {}", mfr_id);
		
		Manufacturer mf = null;
		
		for (Iterator<Manufacturer> iterator = initialData.getData().iterator(); iterator.hasNext();) {
			mf = iterator.next();
			
			if (mf.getMfr_ID().equals(mfr_id )) {
				//found the one
				break;
			}
		}
		
		if (mf != null) {
			initialData.getData().remove(mf);
			saveToFile();
			return true;
		}

		//false indicates failed to remove the element: does not exist
		return false;
	}


	//delete the whole lot of manufacturers
	public Integer deleteManufactorers() 
			throws JsonGenerationException, JsonMappingException, IOException, URISyntaxException {
		
		log.info("deleteManufactorers");
		
		int count = initialData.getData().size();
		
		initialData.getData().clear();

		saveToFile();
		return count;
	}


	//Insert a list of manufacturers
	public CarManufacturerData insertManufactorers(Set<Manufacturer> manufacturers) 
			throws JsonGenerationException, JsonMappingException, IOException, URISyntaxException {
		
		log.info("insertManufactorers");
		//the mfr_Id is uniq, get the next one to make sure the ids are uniq
		//get the current max id
		
		int max = 1;
		try {
			max = initialData.getData().stream().mapToInt(m -> m.getMfr_ID()).max().getAsInt();
		} catch (NoSuchElementException ex) {
			//empty list
			max = 1;
		}
		//enhancement required here: the passed in manufacturers may have manufacturers objects 
		//are identical except the ID. such duplicates should be removed, tmd
		for (Manufacturer mf : manufacturers) {
			mf.setMfr_ID(++max);
		}
		
		//the passed in manufacturers
		initialData.getData().addAll(manufacturers);		
		
		saveToFile();
		
		//return initialData.getData();
		
		//return a sorted list
		return getManufactorers(true, false, null);	
	}

	//change a manufacturer based on id
	public Manufacturer changeManufactorer(Manufacturer manufacturer) 
			throws JsonGenerationException, JsonMappingException, IOException, URISyntaxException {
		
		log.info("changeManufactorer: {}", manufacturer.getMfr_ID());
		
		Manufacturer mf = null;
		
		for (Iterator<Manufacturer> iterator = initialData.getData().iterator(); iterator.hasNext();) {
			mf = iterator.next();
			
			if (mf.getMfr_ID().equals(manufacturer.getMfr_ID() )) {
				//found the one
				break;
			}
		}
		
		if (mf != null) {
			initialData.getData().remove(mf);
		}
		
		initialData.getData().add(manufacturer);
		
		saveToFile();
			
		return manufacturer;
	}
}
