package com.car.mfg.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Manufacturer implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public Manufacturer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Manufacturer(String country, String mfr_CommonName,
    		Integer mfr_ID, String mfr_Name,
			Set<VehicleType> vehicleTypes) {
		super();
		this.country = country;
		Mfr_CommonName = mfr_CommonName;
		Mfr_ID = mfr_ID;
		Mfr_Name = mfr_Name;
		VehicleTypes = vehicleTypes;
	}
	private String country;
    public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getMfr_CommonName() {
		return Mfr_CommonName;
	}
	public void setMfr_CommonName(String mfr_CommonName) {
		Mfr_CommonName = mfr_CommonName;
	}
	public Integer getMfr_ID() {
		return Mfr_ID;
	}
	public void setMfr_ID(Integer mfr_ID) {
		Mfr_ID = mfr_ID;
	}
	public String getMfr_Name() {
		return Mfr_Name;
	}
	public void setMfr_Name(String mfr_Name) {
		Mfr_Name = mfr_Name;
	}
	public Set<VehicleType> getVehicleTypes() {
		return VehicleTypes;
	}
	public void setVehicleTypes(Set<VehicleType> vehicleTypes) {
		VehicleTypes = vehicleTypes;
	}
	private String Mfr_CommonName;
	private Integer Mfr_ID;
	private String Mfr_Name;
	private Set<VehicleType> VehicleTypes;
    
	//
	public Boolean isMatch(String country, String name, String vehicleTypeName) {
		if (country != null) {
			if (country.compareToIgnoreCase(this.getCountry()) != 0) {
				return false;
			}
		}
		
		if (name != null) {
			if (name.compareToIgnoreCase(this.getMfr_Name()) != 0) {
				return false;
			}
		}
		
		if (vehicleTypeName != null) {
			 
			for (VehicleType v : this.getVehicleTypes()) {
				if (v.isMatch(vehicleTypeName))  {
					return true;
				}
			}
			return false;
		} else {
			return true;
		}
	}
	
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Mfr_CommonName == null) ? 0 : Mfr_CommonName.hashCode());
		result = prime * result + ((Mfr_ID == null) ? 0 : Mfr_ID.hashCode());
		result = prime * result + ((Mfr_Name == null) ? 0 : Mfr_Name.hashCode());
		result = prime * result + ((VehicleTypes == null) ? 0 : VehicleTypes.hashCode());
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Manufacturer)) {
			return false;
		}
		Manufacturer other = (Manufacturer) obj;
		if (Mfr_CommonName == null) {
			if (other.Mfr_CommonName != null) {
				return false;
			}
		} else if (!Mfr_CommonName.equals(other.Mfr_CommonName)) {
			return false;
		}
		if (Mfr_ID == null) {
			if (other.Mfr_ID != null) {
				return false;
			}
		} else if (!Mfr_ID.equals(other.Mfr_ID)) {
			return false;
		}
		if (Mfr_Name == null) {
			if (other.Mfr_Name != null) {
				return false;
			}
		} else if (!Mfr_Name.equals(other.Mfr_Name)) {
			return false;
		}
		if (VehicleTypes == null) {
			if (other.VehicleTypes != null) {
				return false;
			}
		} else if (!VehicleTypes.equals(other.VehicleTypes)) {
			return false;
		}
		if (country == null) {
			if (other.country != null) {
				return false;
			}
		} else if (!country.equals(other.country)) {
			return false;
		}
		return true;
	}
}
