package com.car.mfg.exception;

/*
 * boilderplate code:
 * Global exception handlers to customize some exception messages to minimize XSS,CSRF SQL injection issues
 */
import java.io.IOException;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

/*
 * Convert exceptions to HTTP errors for all controllers 
 */
@ControllerAdvice
public class GlobalExceptionConvertor {
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    
    // Method that returns the error response in the standard format
    ResponseEntity<?> errorResponse(Exception ex, HttpStatus status){
    	ErrorResponse errorResponse = null;
 
    	ExceptionBase baseException = (ExceptionBase)ex;
    	errorResponse = new ErrorResponse(status, baseException.getError(), baseException.getMessage(), baseException.getErrorDetail());
    	
    	return new ResponseEntity<ErrorResponse>(errorResponse, status);
    }

    // 400 Bad Request
    @ExceptionHandler
    ResponseEntity<?> handleBadRequest(BadRequestException e) throws IOException {
        log.debug("HTTP Error - BAD REQUEST: {}", e.getMessage());
        return errorResponse(e, HttpStatus.BAD_REQUEST);
    }

    // 400 Bad Request
    @ExceptionHandler
    ResponseEntity<?> handleBadRequest(MethodArgumentNotValidException e) throws IOException {
        log.error("HTTP Error - BAD REQUEST: {}","request parameter not valid ", e.getMessage(), e);
        ExceptionBase base = new ExceptionBase(HttpStatus.BAD_REQUEST.toString(), "Request parameter not valid "+e.getParameter()!=null?e.getParameter().getParameterName():"");
        return errorResponse(base, HttpStatus.BAD_REQUEST);
    }

 // 400 Bad Request
    @ExceptionHandler(MissingServletRequestParameterException.class)
    ResponseEntity<?> handleInvalidExpressionException(MissingServletRequestParameterException e) throws IOException {
        log.error("HTTP Error - BAD REQUEST: {} missing parameter exception", e.getMessage(), e);
        ExceptionBase base = new ExceptionBase(HttpStatus.BAD_REQUEST.toString(), "Missing parameter");
        return errorResponse(base, HttpStatus.BAD_REQUEST);
    }

    // 400 Bad Request
    @ExceptionHandler
    ResponseEntity<?> handleBadRequest(IllegalArgumentException e) throws IOException {
        log.error("HTTP Error - BAD REQUEST: {}", "An illegal parameter was passed to the API ",e.getMessage(), e);
       // we don't want the exception generated to include the original string as it could make the application XSS vulnerable.
        ExceptionBase base = new ExceptionBase(HttpStatus.BAD_REQUEST.toString(), "An illegal parameter was passed to the API : "+e.getMessage());
        return errorResponse(base, HttpStatus.BAD_REQUEST);
    }

    // 400 Bad Request
    @ExceptionHandler
    ResponseEntity<?> handleBadRequest(MethodArgumentTypeMismatchException e) throws IOException {
        log.error("HTTP Error - BAD REQUEST: {}", "Failed to convert the value for parameter ",e.getMessage(), e);
       // we don't want the exception generated to include the original string as it could make the application XSS vulnerable.
        ExceptionBase base = new ExceptionBase(HttpStatus.BAD_REQUEST.toString(), "Failed to convert the value for parameter : "+e.getName());
        return errorResponse(base, HttpStatus.BAD_REQUEST);
    }

    //400 Bad Request - HttpMessageNotReadableException
    @ExceptionHandler(HttpMessageNotReadableException.class)
    ResponseEntity<?> handleMessageNotReadableException(Exception e) throws IOException {
        log.error("HTTP Error - BAD REQUEST: {}", "Failed to parse request ", e.getMessage(), e);
        ExceptionBase base = new ExceptionBase(HttpStatus.BAD_REQUEST.toString(), "Failed to parse payment, please check the payment details.");
        return errorResponse(base, HttpStatus.BAD_REQUEST);
    }

    //405 Method Not Allowed
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    ResponseEntity<?> handleMethodNotSupportedException(Exception e) throws IOException {
        log.error("HTTP Error - METHOD NOT ALLOWED: {}", e.getMessage(), e);
        ExceptionBase base = new ExceptionBase(HttpStatus.METHOD_NOT_ALLOWED.toString(),  "METHOD NOT ALLOWED");
        return errorResponse(base, HttpStatus.METHOD_NOT_ALLOWED);
    }
 
   
    //415 Unsupported Media Type
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    ResponseEntity<?> handleMediaTypeNotSupportedException(Exception e) throws IOException {
        log.error("HTTP Error - UNSUPPORTED MEDIA TYPE: {}", e.getMessage());
        return errorResponse(e, HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    }  

    // 500 Internal Server Error
    @ExceptionHandler
    ResponseEntity<?> handleAllOtherErrors(Exception e) throws IOException {
        log.error("HTTP Error - INTERNAL SERVER ERROR: Exception: {}", e.getMessage(), e);
        return errorResponse(e, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
