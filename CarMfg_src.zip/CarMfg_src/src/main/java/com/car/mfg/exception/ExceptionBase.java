package com.car.mfg.exception;

/*
 * Common details for an exception
 */
public class ExceptionBase extends Exception {

	private static final long serialVersionUID = -6761427052512212889L;
	
	private String	errorCode;
	private String	errorDetail;
	
	public ExceptionBase() {}
	
	public ExceptionBase(String message) {
		super(message);
		errorCode = "";
		errorDetail ="";
	}
	
	public ExceptionBase(String errorCode, String errorMsg)
	{
		super(errorMsg);
		this.errorCode = errorCode;
		errorDetail ="";
	}
	
	public ExceptionBase(String errorCode, String errorMsg, String errorDetail)
	{
		super(errorMsg);
		this.errorCode = errorCode;
		this.errorDetail = errorDetail;
	}	
	
	
	/**
	 * @return the error
	 */
	public String getError() {
		return errorCode;
	}


	public String getErrorDetail() {
		return errorDetail;
	}

	public String getMessageString() {
		return "Error message = "+ getMessage()+"; Error detail = " +  errorDetail;
	}

}
