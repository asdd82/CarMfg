package com.car.mfg.controller;

/*
 * unit tests for the CarMfgController
 */
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.context.WebApplicationContext;

import com.car.mfg.app.CarMfgApplication;
import com.car.mfg.dto.CarManufacturerData;
import com.car.mfg.dto.Manufacturer;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@TestPropertySource(properties = {
        // Use an in-memory DB for testing instead of SQLServer
        "car.mfg.data.folder=src/test/resources"
})

@RunWith(SpringRunner.class)
@SpringBootTest(classes = CarMfgApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class CarMfgControllerTests {

    private MockMvc mockMvc;

    static ObjectMapper mapper = new ObjectMapper();
    
    private static HttpMessageConverter mappingJackson2HttpMessageConverter;
    
    Boolean loadedJSON = false;
    
    private  CarManufacturerData initialData ;
    
    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {

    	//we need the jackson http message converter to serialize/deseralize request/reponse
        mappingJackson2HttpMessageConverter = Arrays.asList(converters)
        		.stream()
        		.filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
        		.findAny()
        		.orElse(null);

        assertNotNull("the JSON message converter must not be null!", this.mappingJackson2HttpMessageConverter);
    }
    
    private MediaType contentType =
            new MediaType(MediaType.APPLICATION_JSON.getType(), 
                MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

    @Autowired
    private WebApplicationContext webApplicationContext;

    //normally, we need this to authenticate the user to create a bearer access JWT token 
    //to access the rest api. For now, it is a dummy one
    private class DummyJWTVerificationFilter implements Filter{

        @Override
        public void destroy() {
        }
        
        public String username = "automationTester";

        @Override
        public void doFilter(    ServletRequest req, 
                                 ServletResponse res, 
                                 FilterChain fc)
                throws IOException, ServletException {
           
            fc.doFilter(req, res);
        }

        @Override
        public void init(FilterConfig arg0) throws ServletException {
            
        }      
    }
   
    
    //objects to json string conversion
    protected static String toJson(Object o) throws IOException {
        if (o != null) {   	       	
            MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
            mappingJackson2HttpMessageConverter.write(o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);
            String str = mockHttpOutputMessage.getBodyAsString();
            return str;
        }
        return "{}";
    }
    
    //json array to list of  manufacturer objects conversion
    protected List<Manufacturer> jsonToObject(String contentAsString) 
    	 throws JsonParseException, JsonMappingException, IOException {
    	 List<Manufacturer> manufacturerRet =  
    			 mapper.readValue(contentAsString.getBytes(), new TypeReference<List<Manufacturer>>() {});
    	 return manufacturerRet;
	}
 
    @Before
    public void setUp() {
        System.out.println("CarMfgControllerTests: setup");

        this.mockMvc = webAppContextSetup(webApplicationContext).addFilter(new DummyJWTVerificationFilter())
                .build();
        
        mapper.findAndRegisterModules();
        
        mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        
        try {
			loadJSON();
		} catch (IOException | CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }

    @After
    public void tearDown() {
        System.out.println("CarMfgControllerTests: teardown");
    }
    
    //load the json test file
    public void loadJSON() throws JsonParseException, JsonMappingException, IOException, CloneNotSupportedException {
    	
        if (!loadedJSON) {
            loadedJSON = true;
            ClassLoader classLoader = getClass().getClassLoader();
            //File srcdir = new File(path);
            File jsonFile = new File(classLoader.getResource("carmfg_data.json").getFile());
           
            initialData = mapper.readValue(jsonFile, new TypeReference<CarManufacturerData>() {});
            initialData.setData(initialData.getData().stream().distinct().collect(Collectors.toList()));            
        }
    }
    
    //convert to one object
    protected static CarManufacturerData jsonToManufacturerData(String response)
            throws JsonParseException, JsonMappingException, IOException {
    	CarManufacturerData mf = mapper.readValue(response.getBytes(), CarManufacturerData.class);
        return mf;
    }
    
    //trigger a GET rest api call
    @Test
    public void testDoGetAll() throws Exception {

    	System.out.println("CarMfgControllerTests: testDoGetAll");
    	 
    	//submit a GET rest api call
    	 MvcResult result = this.mockMvc.perform(
    			 get("/api/car/mfg/v1/manufacturers")
                 .contentType(contentType))
                 .andDo(print())
                 .andExpect(status().is2xxSuccessful())
                 .andReturn();

    	 CarManufacturerData mf = jsonToManufacturerData(result.getResponse().getContentAsString());
    	 
    	 verifyResponseAll(mf); 	 
    }
    
    @Test
    public void testDoGetOne() throws Exception {

    	System.out.println("CarMfgControllerTests: testDoGetOne");
    	 
    	//submit a POST rest api call
    	 MvcResult result = this.mockMvc.perform(
    			 get("/api/car/mfg/v1/manufacturers/955")
                 .contentType(contentType))
                 .andDo(print())
                 .andExpect(status().is2xxSuccessful())
                 .andReturn();

    	 Manufacturer mf = jsonToManufacturer(result.getResponse().getContentAsString());
    	 
    	 verifyResponseOne(mf); 	 
    }
    
    private Manufacturer jsonToManufacturer(String contentAsString)
    		throws JsonParseException, JsonMappingException, IOException {
    	    	Manufacturer mf = mapper.readValue(contentAsString.getBytes(), Manufacturer.class);
    	        return mf;
    }

	private void verifyResponseAll(CarManufacturerData mf) {
    	assertNotNull(initialData.getData());
    	assertNotNull(mf);
    	assertNotNull(mf.getData());
    	assertTrue(initialData.getData().containsAll(mf.getData()));
    	
		
	}

    private void verifyResponseOne(Manufacturer mf ) {
    	assertNotNull(initialData.getData());
    	assertNotNull(mf);
    	assertTrue(initialData.getData().contains(mf));
    	
		
	}
    
    @Test
    public void testDeleteAll() throws Exception {
    	System.out.println("CarMfgControllerTests: testDeleteAll");
    	
    	//tbd
    }
    
    @Test
    public void testDeleteOne() throws Exception {
    	System.out.println("CarMfgControllerTests: testDeleteOne");
    	
    	//tbd
    }
    
    @Test
    public void testInsertOne() throws Exception {
    	System.out.println("CarMfgControllerTests: testInsertOne");
    	
    	//tbd
    }
    
    @Test
    public void testInsertMany() throws Exception {
    	System.out.println("CarMfgControllerTests: testInsertMany");
    	
    	//tbd
    }
    
    @Test
    public void testChangeOne() throws Exception {
    	System.out.println("CarMfgControllerTests: testChangeOne");
    	
    	//tbd
    }
    
    @Test
    public void testInvalidPath() throws Exception {
    	System.out.println("CarMfgControllerTests: testInvalidPath");
    	
    	//tbd
    }
    
    @Test
    public void testInvalidRequestBody() throws Exception {
    	System.out.println("CarMfgControllerTests: testInvalidRequestBody");
    	
    	//tbd
    }
    
    @Test
    public void testSorting() throws Exception {
    	System.out.println("CarMfgControllerTests: testSorting");
    	
    	//tbd
    }
    
    @Test
    public void testOrder() throws Exception {
    	System.out.println("CarMfgControllerTests: testingOrder");
    	
    	//tbd
    }
    
    @Test
    public void testSearch() throws Exception {
    	System.out.println("CarMfgControllerTests: testSearch");
    	
    	//tbd
    }
}
