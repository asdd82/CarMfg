
# Car Manufacturer Service
################################
# Java 8 EE is required to compile this project

# To compile only
cd /d <the source folder that contains pom.xml>
mvn clean compile

# To package without running tests
cd /d <the source folder that contains pom.xml>
mvn clean package -Dmaven.test.skip=true

# To package and publish with running tests
cd /d <the source folder that contains pom.xml>
mvn clean install

# To run Tests only from the command ine
cd /d <the source folder that contains pom.xml>
mvn clean test

# To  package, test, and start the CarMfg web service from the 
# command line
# NOTE: 1. the default port number is 8090, if need to run on different
#          port number see below 
#       2. carmfg_data.json must be in the source folder, or
#          use '-Dcar.mfg.data.folder=<???> pointing to the folder 
#          containing the file, carmfg_data.json
cd /d <the source folder that contains pom.xml>
mvn clean package && java -jar target/CarMfg-0.1.0.jar

# or
mvn clean package && java -Dcar.mfg.data.folder=<the folder containing the json fie> -jar target/CarMfg-0.1.0.jar

# or if carmfg_data.json file is in the source folder, run by doing:
mvn spring-boot:run

# Please note that the default is 8090 that is
# specified in application.properties files
# To start the CarMfg web service from the command line using
# a non-default port number, e.g. 6789, use '-Dserver.port=<???>', e.g.
cd /d <the source folder that contains pom.xml>
mvn clean package && java -Dserver.port=6789 -jar target/CarMfg-0.1.0.jar

# TESTING
# There are junit tests in src/test/java, but there are many incomplete ones

#Running and testing the web services

# Please note that For all methods:
# content-type=application/json

#e.g. use postman to test

# Get all manufacturers. Optionally sort and order and search
GET: return all manufacturers. Optionally sort and order and search
http://localhost:8090/api/car/mfg/v1/manufacturers?sort=true&orderByDesc=true&q=Country:"USA"|Mfr_Name:"TESLA, INC."|VehicleTypeName:"Passenger Car"

# return 1 manufacturer based on id. 
GET: 
http://localhost:8090/api/car/mfg/v1/manufacturers/{id}

# Change 1 manufacturer. 
PATCH: 
http://localhost:8090/api/car/mfg/v1/manufacturer
#input or requestBody
{
    "country" : "United States (USA) testing",
    "mfr_ID" : 52,
    "mfr_Name" : "GENERAL MOTORS LLC testing",
    "vehicleTypes" : [ {
      "isPrimary" : false,
      "name" : "Passenger Car"
}

# Insert one or more manufacturers
POST: 
http://localhost:8090/api/car/mfg/v1/manufacturers
#input or requestBody must be an array
[
{
    "country" : "United States (USA) added 1",
    "mfr_Name" : "GENERAL MOTORS LLC added 1",
    "vehicleTypes" : [ {
      "isPrimary" : false,
      "name" : "Passenger Car"
},
{
    "country" : "United States (USA) added 2",
    "mfr_Name" : "GENERAL MOTORS LLC added 2",
    "vehicleTypes" : [ {
      "isPrimary" : false,
      "name" : "Passenger Car"
}
]

# delete 1 manufacturer based on id. 
DELETE: 
http://localhost:8090/api/car/mfg/v1/manufacturers/{id}

# delete all manufacturers. 
DELETE: 
http://localhost:8090/api/car/mfg/v1/manufacturers

# Save the manufacturer data into a file on the server

# Please note that for delete/post/patch operations, the server saves the manufacturer
# data into a file, carmfg_new_data.json, in the same folder as carmfg_data.json.
# and the duplicates in carmfg_data.json are removed.

 
